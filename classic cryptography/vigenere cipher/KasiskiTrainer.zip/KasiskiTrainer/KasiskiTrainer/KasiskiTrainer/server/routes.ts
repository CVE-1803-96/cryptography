import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertKasiskiAnalysisSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Analyze ciphertext using Kasiski algorithm
  app.post("/api/kasiski/analyze", async (req, res) => {
    try {
      const validatedData = insertKasiskiAnalysisSchema.parse(req.body);
      const analysis = await storage.createKasiskiAnalysis(validatedData);
      res.json(analysis);
    } catch (error) {
      res.status(400).json({ 
        message: error instanceof z.ZodError ? "Invalid analysis data" : "Analysis failed" 
      });
    }
  });

  // Get analysis by ID
  app.get("/api/kasiski/analysis/:id", async (req, res) => {
    try {
      const analysis = await storage.getKasiskiAnalysis(req.params.id);
      if (!analysis) {
        return res.status(404).json({ message: "Analysis not found" });
      }
      res.json(analysis);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve analysis" });
    }
  });

  // Get all analyses
  app.get("/api/kasiski/analyses", async (req, res) => {
    try {
      const analyses = await storage.getUserAnalyses();
      res.json(analyses);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve analyses" });
    }
  });

  // Validate ciphertext format
  app.post("/api/kasiski/validate", async (req, res) => {
    try {
      const { ciphertext } = req.body;
      
      if (!ciphertext || typeof ciphertext !== 'string') {
        return res.status(400).json({ 
          valid: false, 
          message: "Ciphertext is required and must be a string" 
        });
      }

      // Check if ciphertext contains only alphabetic characters
      const cleanText = ciphertext.replace(/[^A-Za-z]/g, '').toUpperCase();
      
      if (cleanText.length < 10) {
        return res.status(400).json({ 
          valid: false, 
          message: "Ciphertext must be at least 10 characters long" 
        });
      }

      res.json({ 
        valid: true, 
        cleanText, 
        originalLength: ciphertext.length,
        cleanLength: cleanText.length
      });
    } catch (error) {
      res.status(500).json({ message: "Validation failed" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
