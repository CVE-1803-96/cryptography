import { type User, type InsertUser, type KasiskiAnalysis, type InsertKasiskiAnalysis } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  createKasiskiAnalysis(analysis: InsertKasiskiAnalysis): Promise<KasiskiAnalysis>;
  getKasiskiAnalysis(id: string): Promise<KasiskiAnalysis | undefined>;
  getUserAnalyses(userId?: string): Promise<KasiskiAnalysis[]>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private kasiskiAnalyses: Map<string, KasiskiAnalysis>;

  constructor() {
    this.users = new Map();
    this.kasiskiAnalyses = new Map();
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async createKasiskiAnalysis(insertAnalysis: InsertKasiskiAnalysis): Promise<KasiskiAnalysis> {
    const id = randomUUID();
    const analysis: KasiskiAnalysis = { 
      ...insertAnalysis, 
      id, 
      createdAt: new Date(),
      plaintext: insertAnalysis.plaintext || null,
      finalKey: insertAnalysis.finalKey || null
    };
    this.kasiskiAnalyses.set(id, analysis);
    return analysis;
  }

  async getKasiskiAnalysis(id: string): Promise<KasiskiAnalysis | undefined> {
    return this.kasiskiAnalyses.get(id);
  }

  async getUserAnalyses(userId?: string): Promise<KasiskiAnalysis[]> {
    return Array.from(this.kasiskiAnalyses.values())
      .sort((a, b) => (b.createdAt?.getTime() || 0) - (a.createdAt?.getTime() || 0));
  }
}

export const storage = new MemStorage();
