import { sql } from "drizzle-orm";
import { pgTable, text, varchar, jsonb, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const kasiskiAnalyses = pgTable("kasiski_analyses", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  ciphertext: text("ciphertext").notNull(),
  patterns: jsonb("patterns").notNull(),
  distances: jsonb("distances").notNull(),
  keyLengthCandidates: jsonb("key_length_candidates").notNull(),
  finalKey: text("final_key"),
  plaintext: text("plaintext"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertKasiskiAnalysisSchema = createInsertSchema(kasiskiAnalyses).omit({
  id: true,
  createdAt: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertKasiskiAnalysis = z.infer<typeof insertKasiskiAnalysisSchema>;
export type KasiskiAnalysis = typeof kasiskiAnalyses.$inferSelect;
