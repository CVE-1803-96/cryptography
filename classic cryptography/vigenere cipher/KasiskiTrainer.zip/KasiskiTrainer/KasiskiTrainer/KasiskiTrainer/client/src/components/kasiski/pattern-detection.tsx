import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ExpandIcon } from "lucide-react";
import { RepeatedPattern } from "@/types/kasiski";

interface PatternDetectionProps {
  patterns: RepeatedPattern[];
  ciphertext: string;
}

export function PatternDetection({ patterns, ciphertext }: PatternDetectionProps) {
  const renderHighlightedText = () => {
    let highlightedText = ciphertext;
    let offset = 0;
    
    // Sort patterns by first occurrence position to avoid overlap issues
    const sortedPatterns = [...patterns].sort((a, b) => a.positions[0] - b.positions[0]);
    
    sortedPatterns.forEach((pattern) => {
      pattern.positions.forEach((position) => {
        const adjustedPos = position + offset;
        const before = highlightedText.slice(0, adjustedPos);
        const highlighted = `<span class="${pattern.highlightClass}">${pattern.pattern}</span>`;
        const after = highlightedText.slice(adjustedPos + pattern.pattern.length);
        
        highlightedText = before + highlighted + after;
        offset += highlighted.length - pattern.pattern.length;
      });
    });
    
    return { __html: highlightedText };
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
      {/* Highlighted Ciphertext */}
      <Card className="bg-card dark:bg-card border border-border dark:border-border">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg font-semibold">Repeated Patterns</CardTitle>
            <Button variant="ghost" size="sm" data-testid="button-expand-patterns">
              <ExpandIcon className="mr-1 h-4 w-4" />
              Expand
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div 
            className="cipher-text bg-muted dark:bg-muted p-4 rounded-lg mb-4 text-sm break-all"
            dangerouslySetInnerHTML={renderHighlightedText()}
            data-testid="highlighted-ciphertext"
          />
          
          <div className="space-y-3">
            {patterns.slice(0, 5).map((pattern, index) => (
              <div 
                key={`${pattern.pattern}-${index}`}
                className="flex items-center justify-between p-3 bg-secondary/30 dark:bg-secondary/30 rounded-lg"
                data-testid={`pattern-item-${index}`}
              >
                <div className="flex items-center gap-3">
                  <div className={`w-4 h-4 ${pattern.highlightClass} rounded`}></div>
                  <span className="font-mono font-medium">{pattern.pattern}</span>
                </div>
                <div className="text-sm text-muted-foreground dark:text-muted-foreground">
                  Positions: {pattern.positions.join(', ')}
                  {pattern.distances.length > 0 && (
                    <span> (Distances: {pattern.distances.join(', ')})</span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
      
      {/* Pattern Statistics */}
      <Card className="bg-card dark:bg-card border border-border dark:border-border">
        <CardHeader>
          <CardTitle className="text-lg font-semibold">Pattern Statistics</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="p-4 bg-accent/5 dark:bg-accent/5 border border-accent/20 dark:border-accent/20 rounded-lg">
              <h4 className="font-medium text-accent dark:text-accent mb-2">Analysis Summary</h4>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-muted-foreground dark:text-muted-foreground">Total Patterns:</span>
                  <span className="ml-2 font-mono font-medium" data-testid="total-patterns">
                    {patterns.length}
                  </span>
                </div>
                <div>
                  <span className="text-muted-foreground dark:text-muted-foreground">Unique Distances:</span>
                  <span className="ml-2 font-mono font-medium" data-testid="unique-distances">
                    {new Set(patterns.flatMap(p => p.distances)).size}
                  </span>
                </div>
              </div>
            </div>
            
            <div className="space-y-2">
              <h4 className="font-medium">Most Common Patterns</h4>
              {patterns.slice(0, 3).map((pattern, index) => (
                <div 
                  key={`common-${pattern.pattern}-${index}`}
                  className="flex items-center justify-between p-2 bg-secondary/20 dark:bg-secondary/20 rounded"
                  data-testid={`common-pattern-${index}`}
                >
                  <span className="font-mono font-medium">{pattern.pattern}</span>
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-muted-foreground dark:text-muted-foreground">
                      Occurrences: {pattern.positions.length}
                    </span>
                    <div className={`w-12 h-2 ${pattern.highlightClass} rounded-full`}></div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
