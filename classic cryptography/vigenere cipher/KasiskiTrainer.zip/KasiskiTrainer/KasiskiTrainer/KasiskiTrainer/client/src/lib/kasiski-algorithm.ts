import { RepeatedPattern, DistanceAnalysis, KeyLengthCandidate, FrequencyAnalysis, KeySolution } from "../types/kasiski";

export class KasiskiAlgorithm {
  private ciphertext: string;

  constructor(ciphertext: string) {
    this.ciphertext = ciphertext.replace(/[^A-Za-z]/g, '').toUpperCase();
  }

  // Step 1: Find repeated patterns of length 3 or more
  findRepeatedPatterns(minLength: number = 3): RepeatedPattern[] {
    const patterns: Map<string, number[]> = new Map();
    const text = this.ciphertext;
    const highlightClasses = ['highlight-1', 'highlight-2', 'highlight-3', 'highlight-4', 'highlight-5'];
    
    // Find all patterns
    for (let length = minLength; length <= Math.min(6, text.length / 3); length++) {
      for (let i = 0; i <= text.length - length; i++) {
        const pattern = text.substring(i, i + length);
        if (!patterns.has(pattern)) {
          patterns.set(pattern, []);
        }
        patterns.get(pattern)!.push(i);
      }
    }

    // Filter patterns that appear at least twice
    const repeatedPatterns: RepeatedPattern[] = [];
    let colorIndex = 0;
    
    patterns.forEach((positions, pattern) => {
      if (positions.length >= 2) {
        const distances = this.calculateDistances(positions);
        repeatedPatterns.push({
          pattern,
          positions,
          distances,
          highlightClass: highlightClasses[colorIndex % highlightClasses.length]
        });
        colorIndex++;
      }
    });

    // Sort by pattern length (longer patterns first) then by frequency
    return repeatedPatterns.sort((a, b) => {
      if (a.pattern.length !== b.pattern.length) {
        return b.pattern.length - a.pattern.length;
      }
      return b.positions.length - a.positions.length;
    }).slice(0, 10); // Limit to top 10 patterns
  }

  // Step 2: Calculate distances between pattern occurrences
  private calculateDistances(positions: number[]): number[] {
    const distances: number[] = [];
    for (let i = 0; i < positions.length - 1; i++) {
      for (let j = i + 1; j < positions.length; j++) {
        distances.push(positions[j] - positions[i]);
      }
    }
    return distances;
  }

  // Step 3: Analyze distances to find common factors
  analyzeDistances(patterns: RepeatedPattern[]): DistanceAnalysis[] {
    const distanceCount: Map<number, number> = new Map();
    
    patterns.forEach(pattern => {
      pattern.distances.forEach(distance => {
        distanceCount.set(distance, (distanceCount.get(distance) || 0) + 1);
      });
    });

    const analyses: DistanceAnalysis[] = [];
    distanceCount.forEach((count, distance) => {
      const factors = this.findFactors(distance);
      analyses.push({
        distance,
        count,
        factors
      });
    });

    return analyses.sort((a, b) => b.count - a.count);
  }

  // Step 4: Determine probable key lengths
  determineKeyLengths(distanceAnalyses: DistanceAnalysis[]): KeyLengthCandidate[] {
    const factorCount: Map<number, number> = new Map();
    
    distanceAnalyses.forEach(analysis => {
      analysis.factors.forEach(factor => {
        if (factor >= 2 && factor <= 20) { // Reasonable key length range
          factorCount.set(factor, (factorCount.get(factor) || 0) + analysis.count);
        }
      });
    });

    const candidates: KeyLengthCandidate[] = [];
    const totalOccurrences = Array.from(factorCount.values()).reduce((sum, count) => sum + count, 0);
    
    factorCount.forEach((occurrences, length) => {
      const confidence = Math.min(95, (occurrences / totalOccurrences) * 100);
      candidates.push({
        length,
        confidence,
        occurrences,
        factors: distanceAnalyses
          .filter(d => d.factors.includes(length))
          .map(d => d.distance)
      });
    });

    return candidates
      .sort((a, b) => b.confidence - a.confidence)
      .slice(0, 5); // Top 5 candidates
  }

  // Step 5: Perform frequency analysis for each position in the key
  performFrequencyAnalysis(keyLength: number): FrequencyAnalysis[] {
    const analyses: FrequencyAnalysis[] = [];
    const englishFreq = {
      'A': 8.12, 'B': 1.49, 'C': 2.78, 'D': 4.25, 'E': 12.02, 'F': 2.23,
      'G': 2.02, 'H': 6.09, 'I': 6.97, 'J': 0.15, 'K': 0.77, 'L': 4.03,
      'M': 2.41, 'N': 6.75, 'O': 7.51, 'P': 1.93, 'Q': 0.10, 'R': 5.99,
      'S': 6.33, 'T': 9.06, 'U': 2.76, 'V': 0.98, 'W': 2.36, 'X': 0.15,
      'Y': 1.97, 'Z': 0.07
    };

    for (let pos = 0; pos < keyLength; pos++) {
      const letters: { [key: string]: number } = {};
      let total = 0;

      // Collect letters at this position
      for (let i = pos; i < this.ciphertext.length; i += keyLength) {
        const letter = this.ciphertext[i];
        letters[letter] = (letters[letter] || 0) + 1;
        total++;
      }

      // Calculate chi-squared for each possible shift
      let bestShift = 'A';
      let bestScore = Infinity;
      
      for (let shift = 0; shift < 26; shift++) {
        let chiSquared = 0;
        
        for (let i = 0; i < 26; i++) {
          const letter = String.fromCharCode(65 + i);
          const shiftedLetter = String.fromCharCode(65 + ((i - shift + 26) % 26));
          const observed = letters[letter] || 0;
          const expected = (englishFreq[shiftedLetter as keyof typeof englishFreq] || 0) * total / 100;
          
          if (expected > 0) {
            chiSquared += Math.pow(observed - expected, 2) / expected;
          }
        }
        
        if (chiSquared < bestScore) {
          bestScore = chiSquared;
          bestShift = String.fromCharCode(65 + shift);
        }
      }

      const confidence = Math.max(0, Math.min(100, 100 - (bestScore / total) * 10));
      
      analyses.push({
        position: pos,
        letters,
        mostLikely: bestShift,
        confidence
      });
    }

    return analyses;
  }

  // Step 6: Reconstruct the key
  reconstructKey(frequencyAnalyses: FrequencyAnalysis[]): string {
    return frequencyAnalyses.map(analysis => analysis.mostLikely).join('');
  }

  // Step 7: Decrypt the ciphertext
  decryptText(key: string): string {
    let plaintext = '';
    const keyLength = key.length;
    
    for (let i = 0; i < this.ciphertext.length; i++) {
      const cipherChar = this.ciphertext[i];
      const keyChar = key[i % keyLength];
      const shift = keyChar.charCodeAt(0) - 65;
      const decryptedChar = String.fromCharCode(((cipherChar.charCodeAt(0) - 65 - shift + 26) % 26) + 65);
      plaintext += decryptedChar;
    }
    
    return plaintext;
  }

  // Helper: Find all factors of a number
  private findFactors(n: number): number[] {
    const factors: number[] = [];
    for (let i = 2; i <= Math.sqrt(n); i++) {
      if (n % i === 0) {
        factors.push(i);
        if (i !== n / i) {
          factors.push(n / i);
        }
      }
    }
    if (n > 1) factors.push(n);
    return factors.sort((a, b) => a - b);
  }

  // Generate multiple key solutions for user selection
  generateKeySolutions(keyLengthCandidates: KeyLengthCandidate[]): KeySolution[] {
    const solutions: KeySolution[] = [];
    const topCandidates = keyLengthCandidates.slice(0, 3);
    
    topCandidates.forEach((candidate, index) => {
      const frequencyAnalysis = this.performFrequencyAnalysis(candidate.length);
      const reconstructedKey = this.reconstructKey(frequencyAnalysis);
      const plaintext = this.decryptText(reconstructedKey);
      
      // Calculate overall confidence based on key length confidence and frequency analysis
      const avgFreqConfidence = frequencyAnalysis.reduce((sum, f) => sum + f.confidence, 0) / frequencyAnalysis.length;
      const overallConfidence = (candidate.confidence * 0.6) + (avgFreqConfidence * 0.4);
      
      const labels: ('Best' | 'Alternative' | 'Unlikely')[] = ['Best', 'Alternative', 'Unlikely'];
      
      solutions.push({
        keyLength: candidate.length,
        reconstructedKey,
        plaintext,
        confidence: overallConfidence,
        label: labels[index] || 'Unlikely',
        frequencyAnalysis
      });
    });
    
    return solutions;
  }

  // Perform complete analysis with multiple solutions
  performCompleteAnalysis(): {
    ciphertext: string;
    patterns: RepeatedPattern[];
    distances: DistanceAnalysis[];
    keyLengthCandidates: KeyLengthCandidate[];
    keySolutions: KeySolution[];
    selectedSolution: KeySolution;
  } {
    const patterns = this.findRepeatedPatterns();
    const distances = this.analyzeDistances(patterns);
    const keyLengthCandidates = this.determineKeyLengths(distances);
    
    // Generate multiple solutions
    const keySolutions = this.generateKeySolutions(keyLengthCandidates);
    const selectedSolution = keySolutions[0]; // Default to best solution

    return {
      ciphertext: this.ciphertext,
      patterns,
      distances,
      keyLengthCandidates,
      keySolutions,
      selectedSolution
    };
  }
}
