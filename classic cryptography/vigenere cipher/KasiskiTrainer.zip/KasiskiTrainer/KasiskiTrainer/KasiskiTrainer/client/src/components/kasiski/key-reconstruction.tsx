import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Key, Check } from "lucide-react";
import { FrequencyAnalysis } from "@/types/kasiski";

interface KeyReconstructionProps {
  frequencyAnalysis: FrequencyAnalysis[];
  reconstructedKey: string;
}

export function KeyReconstruction({ frequencyAnalysis, reconstructedKey }: KeyReconstructionProps) {
  const averageConfidence = frequencyAnalysis.reduce((sum, analysis) => sum + analysis.confidence, 0) / frequencyAnalysis.length;
  const highConfidencePositions = frequencyAnalysis.filter(a => a.confidence > 70).length;

  return (
    <div className="space-y-6">
      {/* Key Reconstruction Header */}
      <Card className="bg-card dark:bg-card border border-border dark:border-border">
        <CardHeader>
          <div className="flex items-center gap-3">
            <div className="p-2 bg-accent/10 dark:bg-accent/10 rounded-lg">
              <Key className="h-5 w-5 text-accent dark:text-accent" />
            </div>
            <div>
              <CardTitle className="text-lg font-semibold">Key Reconstruction</CardTitle>
              <p className="text-sm text-muted-foreground dark:text-muted-foreground">
                Building the encryption key from frequency analysis results
              </p>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Reconstructed Key Display */}
      <Card className="bg-gradient-to-br from-accent/5 to-accent/10 dark:from-accent/5 dark:to-accent/10 border-2 border-accent/20 dark:border-accent/20">
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-accent dark:text-accent">
            Reconstructed Key
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center mb-6">
            <div 
              className="text-4xl font-mono font-bold text-accent dark:text-accent mb-2 tracking-wider"
              data-testid="reconstructed-key"
            >
              {reconstructedKey}
            </div>
            <Badge 
              variant="default"
              className="bg-accent text-accent-foreground dark:bg-accent dark:text-accent-foreground"
            >
              Length: {reconstructedKey.length}
            </Badge>
          </div>
          
          <div className="grid grid-cols-2 gap-4 mb-4">
            <div className="text-center p-3 bg-card dark:bg-card rounded-lg border border-border dark:border-border">
              <div className="text-lg font-bold text-accent dark:text-accent" data-testid="average-confidence">
                {Math.round(averageConfidence)}%
              </div>
              <div className="text-sm text-muted-foreground dark:text-muted-foreground">
                Average Confidence
              </div>
            </div>
            <div className="text-center p-3 bg-card dark:bg-card rounded-lg border border-border dark:border-border">
              <div className="text-lg font-bold text-accent dark:text-accent" data-testid="high-confidence-positions">
                {highConfidencePositions}/{frequencyAnalysis.length}
              </div>
              <div className="text-sm text-muted-foreground dark:text-muted-foreground">
                High Confidence
              </div>
            </div>
          </div>
          
          <Progress 
            value={averageConfidence} 
            className="w-full h-3"
            data-testid="overall-confidence-progress"
          />
        </CardContent>
      </Card>

      {/* Position-by-Position Analysis */}
      <Card className="bg-card dark:bg-card border border-border dark:border-border">
        <CardHeader>
          <CardTitle className="text-lg font-semibold">Position Analysis</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {frequencyAnalysis.map((analysis, index) => (
              <div
                key={`position-${analysis.position}`}
                className={`p-4 rounded-lg border-2 transition-all ${
                  analysis.confidence > 70
                    ? "bg-accent/5 border-accent/20 dark:bg-accent/5 dark:border-accent/20"
                    : analysis.confidence > 50
                    ? "bg-chart-2/5 border-chart-2/20 dark:bg-chart-2/5 dark:border-chart-2/20"
                    : "bg-secondary/30 border-border dark:bg-secondary/30 dark:border-border"
                }`}
                data-testid={`key-position-${index}`}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-muted-foreground dark:text-muted-foreground">
                    Position {analysis.position + 1}
                  </span>
                  {analysis.confidence > 70 && (
                    <Check className="h-4 w-4 text-accent dark:text-accent" />
                  )}
                </div>
                
                <div className="text-center mb-3">
                  <div className="text-2xl font-mono font-bold text-accent dark:text-accent">
                    {analysis.mostLikely}
                  </div>
                  <div className="text-xs text-muted-foreground dark:text-muted-foreground">
                    Confidence: {Math.round(analysis.confidence)}%
                  </div>
                </div>
                
                <Progress 
                  value={analysis.confidence} 
                  className="w-full h-2"
                  data-testid={`position-confidence-${index}`}
                />
                
                <div className="mt-2 text-xs text-muted-foreground dark:text-muted-foreground">
                  {Object.entries(analysis.letters).length} letters analyzed
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Reconstruction Method */}
      <Card className="bg-card dark:bg-card border border-border dark:border-border">
        <CardHeader>
          <CardTitle className="text-lg font-semibold">Reconstruction Method</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground dark:text-muted-foreground">
              The key was reconstructed using frequency analysis and chi-squared testing:
            </p>
            
            <ol className="list-decimal list-inside space-y-2 text-sm">
              <li>Letters at each key position were grouped separately</li>
              <li>Frequency distribution was calculated for each position</li>
              <li>Chi-squared test compared each possible shift against English letter frequencies</li>
              <li>The shift with the lowest chi-squared value was selected for each position</li>
              <li>All position letters were combined to form the complete key</li>
            </ol>
            
            <div className="p-4 bg-accent/5 dark:bg-accent/5 border border-accent/20 dark:border-accent/20 rounded-lg">
              <div className="font-medium text-accent dark:text-accent mb-2">Quality Assessment:</div>
              <ul className="text-sm text-muted-foreground dark:text-muted-foreground space-y-1">
                <li>• Average confidence: {Math.round(averageConfidence)}%</li>
                <li>• High confidence positions: {highConfidencePositions}/{frequencyAnalysis.length}</li>
                <li>• Key length: {reconstructedKey.length} characters</li>
                <li>• Analysis method: Chi-squared frequency analysis</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
