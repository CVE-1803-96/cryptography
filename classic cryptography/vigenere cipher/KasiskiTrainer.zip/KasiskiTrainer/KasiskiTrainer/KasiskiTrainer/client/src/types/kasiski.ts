export interface RepeatedPattern {
  pattern: string;
  positions: number[];
  distances: number[];
  highlightClass: string;
}

export interface DistanceAnalysis {
  distance: number;
  count: number;
  factors: number[];
}

export interface KeyLengthCandidate {
  length: number;
  confidence: number;
  occurrences: number;
  factors: number[];
}

export interface FrequencyAnalysis {
  position: number;
  letters: { [key: string]: number };
  mostLikely: string;
  confidence: number;
}

export interface KasiskiStep {
  id: number;
  name: string;
  completed: boolean;
  active: boolean;
  icon: string;
}

export interface KeySolution {
  keyLength: number;
  reconstructedKey: string;
  plaintext: string;
  confidence: number;
  label: 'Best' | 'Alternative' | 'Unlikely';
  frequencyAnalysis: FrequencyAnalysis[];
}

export interface KasiskiAnalysisResult {
  ciphertext: string;
  patterns: RepeatedPattern[];
  distances: DistanceAnalysis[];
  keyLengthCandidates: KeyLengthCandidate[];
  keySolutions: KeySolution[];
  selectedSolution: KeySolution;
  currentStep: number;
}
