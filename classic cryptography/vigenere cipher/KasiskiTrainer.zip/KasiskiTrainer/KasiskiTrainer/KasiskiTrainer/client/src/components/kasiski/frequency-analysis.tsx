import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { FrequencyAnalysis as FrequencyAnalysisType } from "@/types/kasiski";

interface FrequencyAnalysisProps {
  analyses: FrequencyAnalysisType[];
  keyLength: number;
}

export function FrequencyAnalysis({ analyses, keyLength }: FrequencyAnalysisProps) {
  const renderLetterFrequencies = (analysis: FrequencyAnalysisType) => {
    const total = Object.values(analysis.letters).reduce((sum, count) => sum + count, 0);
    const sortedLetters = Object.entries(analysis.letters)
      .sort(([, a], [, b]) => b - a)
      .slice(0, 5);
    
    return sortedLetters.map(([letter, count]) => ({
      letter,
      frequency: ((count / total) * 100).toFixed(1),
      count
    }));
  };

  return (
    <div className="space-y-6">
      <Card className="bg-card dark:bg-card border border-border dark:border-border">
        <CardHeader>
          <CardTitle className="text-lg font-semibold">
            Frequency Analysis (Key Length: {keyLength})
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground dark:text-muted-foreground mb-4">
            Analyzing letter frequencies at each key position to determine the most likely cipher alphabet shifts.
          </p>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-4">
        {analyses.map((analysis, index) => (
          <Card 
            key={`freq-analysis-${analysis.position}`}
            className="bg-card dark:bg-card border border-border dark:border-border"
          >
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-medium">
                  Position {analysis.position + 1}
                </CardTitle>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-muted-foreground dark:text-muted-foreground">
                    Key Letter:
                  </span>
                  <span 
                    className="font-mono font-bold text-accent dark:text-accent px-2 py-1 bg-accent/10 dark:bg-accent/10 rounded"
                    data-testid={`key-letter-${index}`}
                  >
                    {analysis.mostLikely}
                  </span>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs text-muted-foreground dark:text-muted-foreground">
                    Confidence:
                  </span>
                  <span className="text-xs font-medium">
                    {Math.round(analysis.confidence)}%
                  </span>
                </div>
                <Progress 
                  value={analysis.confidence} 
                  className="w-full h-2"
                  data-testid={`frequency-confidence-${index}`}
                />
                
                <div className="space-y-2">
                  <div className="text-xs font-medium">Top Letters:</div>
                  {renderLetterFrequencies(analysis).map(({ letter, frequency, count }) => (
                    <div 
                      key={`freq-${analysis.position}-${letter}`}
                      className="flex items-center justify-between text-xs"
                      data-testid={`letter-frequency-${index}-${letter}`}
                    >
                      <span className="font-mono">{letter}</span>
                      <div className="flex items-center gap-2">
                        <span className="text-muted-foreground dark:text-muted-foreground">
                          {frequency}% ({count})
                        </span>
                        <div 
                          className="h-2 bg-chart-1 dark:bg-chart-1 rounded-full"
                          style={{ width: `${Math.max(4, parseFloat(frequency) * 2)}px` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
      
      {/* Summary Statistics */}
      <Card className="bg-card dark:bg-card border border-border dark:border-border">
        <CardHeader>
          <CardTitle className="text-lg font-semibold">Analysis Summary</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center p-4 bg-secondary/30 dark:bg-secondary/30 rounded-lg">
              <div className="text-2xl font-bold text-accent dark:text-accent" data-testid="avg-confidence">
                {Math.round(analyses.reduce((sum, a) => sum + a.confidence, 0) / analyses.length)}%
              </div>
              <div className="text-sm text-muted-foreground dark:text-muted-foreground">
                Avg Confidence
              </div>
            </div>
            <div className="text-center p-4 bg-secondary/30 dark:bg-secondary/30 rounded-lg">
              <div className="text-2xl font-bold text-accent dark:text-accent" data-testid="high-confidence-count">
                {analyses.filter(a => a.confidence > 70).length}
              </div>
              <div className="text-sm text-muted-foreground dark:text-muted-foreground">
                High Confidence
              </div>
            </div>
            <div className="text-center p-4 bg-secondary/30 dark:bg-secondary/30 rounded-lg">
              <div className="text-2xl font-bold text-accent dark:text-accent">
                {keyLength}
              </div>
              <div className="text-sm text-muted-foreground dark:text-muted-foreground">
                Key Positions
              </div>
            </div>
            <div className="text-center p-4 bg-secondary/30 dark:bg-secondary/30 rounded-lg">
              <div className="text-2xl font-bold text-accent dark:text-accent">
                {analyses.map(a => a.mostLikely).join('').substring(0, 4)}
                {analyses.length > 4 ? '...' : ''}
              </div>
              <div className="text-sm text-muted-foreground dark:text-muted-foreground">
                Partial Key
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
