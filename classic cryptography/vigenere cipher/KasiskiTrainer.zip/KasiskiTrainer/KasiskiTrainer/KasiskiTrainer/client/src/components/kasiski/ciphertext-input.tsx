import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { CheckCircle } from "lucide-react";

interface CiphertextInputProps {
  ciphertext: string;
  onCiphertextChange: (value: string) => void;
  onExampleSelect: (example: string) => void;
  examples: { name: string; value: string }[];
}

export function CiphertextInput({ 
  ciphertext, 
  onCiphertextChange, 
  onExampleSelect,
  examples 
}: CiphertextInputProps) {
  const [validationStatus, setValidationStatus] = useState<{
    valid: boolean;
    message: string;
  }>({ valid: false, message: "" });

  const validateInput = (text: string) => {
    if (!text.trim()) {
      setValidationStatus({ valid: false, message: "Please enter a ciphertext" });
      return;
    }

    const cleanText = text.replace(/[^A-Za-z]/g, '');
    if (cleanText.length < 10) {
      setValidationStatus({ 
        valid: false, 
        message: "Ciphertext must be at least 10 characters long" 
      });
      return;
    }

    setValidationStatus({ valid: true, message: "Valid ciphertext format" });
  };

  const handleCiphertextChange = (value: string) => {
    onCiphertextChange(value);
    validateInput(value);
  };

  const handleExampleSelect = (value: string) => {
    if (value && value !== "custom") {
      onExampleSelect(value);
      const example = examples.find(ex => ex.name === value);
      if (example) {
        validateInput(example.value);
      }
    }
  };

  const cleanLength = ciphertext.replace(/[^A-Za-z]/g, '').length;

  return (
    <Card className="bg-card dark:bg-card border border-border dark:border-border">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold">Ciphertext Input</CardTitle>
          <Select onValueChange={handleExampleSelect} data-testid="select-example">
            <SelectTrigger className="w-48 bg-secondary dark:bg-secondary text-secondary-foreground dark:text-secondary-foreground">
              <SelectValue placeholder="Select example..." />
            </SelectTrigger>
            <SelectContent>
              {examples.map((example) => (
                <SelectItem key={example.name} value={example.name}>
                  {example.name}
                </SelectItem>
              ))}
              <SelectItem value="custom">Custom Input</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </CardHeader>
      <CardContent>
        <Textarea
          value={ciphertext}
          onChange={(e) => handleCiphertextChange(e.target.value)}
          placeholder="Enter your Vigenère ciphertext here..."
          className="w-full h-24 p-3 bg-input dark:bg-input border border-border dark:border-border rounded-lg font-mono text-sm resize-none"
          data-testid="textarea-ciphertext"
        />
        <div className="flex items-center justify-between mt-2">
          <div className="flex items-center gap-4">
            <span className="text-sm text-muted-foreground dark:text-muted-foreground">
              Length: <span className="font-mono" data-testid="text-length">{cleanLength}</span>
            </span>
            <div className="flex items-center gap-1">
              <div className={`w-2 h-2 rounded-full ${validationStatus.valid ? 'bg-chart-1' : 'bg-destructive'}`}></div>
              <span className="text-sm text-muted-foreground dark:text-muted-foreground" data-testid="validation-status">
                {validationStatus.message || "Enter text to validate"}
              </span>
            </div>
          </div>
          <Button 
            variant="ghost" 
            size="sm"
            onClick={() => validateInput(ciphertext)}
            className="text-accent hover:text-accent/80 dark:text-accent dark:hover:text-accent/80"
            data-testid="button-validate"
          >
            <CheckCircle className="mr-1 h-4 w-4" />
            Validate
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
