import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Star } from "lucide-react";
import { KeyLengthCandidate } from "@/types/kasiski";

interface KeyLengthAnalysisProps {
  keyLengthCandidates: KeyLengthCandidate[];
}

export function KeyLengthAnalysis({ keyLengthCandidates }: KeyLengthAnalysisProps) {
  const topCandidates = keyLengthCandidates.slice(0, 3);
  
  return (
    <Card className="bg-card dark:bg-card border border-border dark:border-border mb-6">
      <CardHeader>
        <CardTitle className="text-lg font-semibold">Key Length Analysis</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          {topCandidates.map((candidate, index) => (
            <div
              key={`candidate-${candidate.length}-${index}`}
              className={`p-4 rounded-lg border-2 transition-all ${
                index === 0
                  ? "bg-gradient-to-br from-accent/5 to-accent/10 border-accent/20 dark:from-accent/5 dark:to-accent/10 dark:border-accent/20"
                  : "bg-secondary/30 border-border dark:bg-secondary/30 dark:border-border"
              }`}
              data-testid={`key-length-candidate-${index}`}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-2xl font-bold text-accent dark:text-accent">
                  {candidate.length}
                </span>
                {index === 0 && (
                  <div className="flex items-center text-accent dark:text-accent">
                    <Star className="h-4 w-4 mr-1" />
                    <span className="text-sm">Best</span>
                  </div>
                )}
                {index === 1 && (
                  <span className="text-sm text-muted-foreground dark:text-muted-foreground">
                    Alternative
                  </span>
                )}
                {index === 2 && (
                  <span className="text-sm text-muted-foreground dark:text-muted-foreground">
                    Unlikely
                  </span>
                )}
              </div>
              <div className="text-sm text-muted-foreground dark:text-muted-foreground mb-2">
                Confidence: <span className="font-medium">{Math.round(candidate.confidence)}%</span>
              </div>
              <Progress 
                value={candidate.confidence} 
                className="w-full h-2"
                data-testid={`confidence-progress-${index}`}
              />
              <div className="mt-2 text-xs text-muted-foreground dark:text-muted-foreground">
                Occurrences: {candidate.occurrences}
              </div>
            </div>
          ))}
        </div>
        
        {/* Detailed Analysis */}
        <div className="space-y-4">
          <h4 className="font-medium">Detailed Factor Analysis</h4>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border dark:border-border">
                  <th className="text-left py-2">Key Length</th>
                  <th className="text-left py-2">Confidence</th>
                  <th className="text-left py-2">Supporting Distances</th>
                  <th className="text-left py-2">Factor Count</th>
                </tr>
              </thead>
              <tbody>
                {keyLengthCandidates.slice(0, 5).map((candidate, index) => (
                  <tr 
                    key={`table-${candidate.length}-${index}`}
                    className="border-b border-border/50 dark:border-border/50"
                    data-testid={`factor-analysis-row-${index}`}
                  >
                    <td className="py-2 font-mono font-medium">{candidate.length}</td>
                    <td className="py-2">
                      <Badge 
                        variant={candidate.confidence > 70 ? "default" : "secondary"}
                        className={candidate.confidence > 70 ? "bg-accent text-accent-foreground dark:bg-accent dark:text-accent-foreground" : ""}
                      >
                        {Math.round(candidate.confidence)}%
                      </Badge>
                    </td>
                    <td className="py-2 font-mono text-xs">
                      {candidate.factors.slice(0, 3).join(', ')}
                      {candidate.factors.length > 3 && '...'}
                    </td>
                    <td className="py-2">{candidate.factors.length}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
