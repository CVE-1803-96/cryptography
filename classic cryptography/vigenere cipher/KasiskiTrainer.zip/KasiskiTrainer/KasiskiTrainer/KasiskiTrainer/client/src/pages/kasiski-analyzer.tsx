import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Sidebar } from "@/components/kasiski/sidebar";
import { CiphertextInput } from "../components/kasiski/ciphertext-input";
import { PatternDetection } from "../components/kasiski/pattern-detection";
import { DistanceAnalysis } from "../components/kasiski/distance-analysis";
import { KeyLengthAnalysis } from "../components/kasiski/key-length-analysis";
import { FrequencyAnalysis } from "../components/kasiski/frequency-analysis";
import { KeyReconstruction } from "../components/kasiski/key-reconstruction";
import { FinalDecryption } from "../components/kasiski/final-decryption";
import { Button } from "@/components/ui/button";
import { Settings, HelpCircle, Play, RotateCcw } from "lucide-react";
import { KasiskiStep, KasiskiAnalysisResult } from "@/types/kasiski";
import { KasiskiAlgorithm } from "@/lib/kasiski-algorithm";

const EXAMPLE_CIPHERTEXTS = [
  {
    name: "Example 1: CRYPTO",
    value: "LXFOPVEFRNHRFWPBEUNACUNSTLFRVVZXJWUUOFNORURKGPFVGNKBPRYCTRMWXPBQMGKUYLMZNGOYXLXFGCJSTFUPFTXUWWRKGPAXLFRVVZXJWUUOFNORURKGP"
  },
  {
    name: "Example 2: SECRET",
    value: "KBHMPBMSMGKMGOPVBAMHKQGXQTHKBZMDHHGLSHKCCMOIASGNVBWFCCHHMCVFKMGOPVBAMHKQGXQTHKBZMDHHGLSHKCCMOIASGNVBWFCCHHMCVF"
  },
  {
    name: "Example 3: HIDDEN",
    value: "HQKLMVQZPLZKDQRWJBPWQRRXFNQDQGLTZQSPBNKDRWJBPWQRRXFNQDQGLTZQSPBNKDRHQKLMVQZPLZKDQRWJBPWQRRXFNQDQGLTZQSPBNKD"
  }
];

const INITIAL_STEPS: KasiskiStep[] = [
  { id: 1, name: "Input Ciphertext", completed: false, active: false, icon: "fas fa-keyboard" },
  { id: 2, name: "Find Repeated Patterns", completed: false, active: false, icon: "fas fa-search" },
  { id: 3, name: "Calculate Distances", completed: false, active: false, icon: "fas fa-ruler" },
  { id: 4, name: "Factor Analysis", completed: false, active: false, icon: "fas fa-calculator" },
  { id: 5, name: "Frequency Analysis", completed: false, active: false, icon: "fas fa-chart-bar" },
  { id: 6, name: "Key Reconstruction", completed: false, active: false, icon: "fas fa-key" },
  { id: 7, name: "Final Decryption", completed: false, active: false, icon: "fas fa-unlock" },
];

export default function KasiskiAnalyzer() {
  const [ciphertext, setCiphertext] = useState("");
  const [steps, setSteps] = useState<KasiskiStep[]>(INITIAL_STEPS);
  const [currentStep, setCurrentStep] = useState(1);
  const [analysisResult, setAnalysisResult] = useState<KasiskiAnalysisResult | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const updateStepStatus = (stepId: number, completed: boolean, active: boolean = false) => {
    setSteps(prevSteps =>
      prevSteps.map(step => ({
        ...step,
        completed: step.id < stepId ? true : step.id === stepId ? completed : false,
        active: step.id === stepId ? active : false
      }))
    );
  };

  const handleStartAnalysis = async () => {
    if (!ciphertext.trim()) return;
    
    setIsAnalyzing(true);
    setCurrentStep(1);
    updateStepStatus(1, true, true);

    try {
      // Simulate step-by-step analysis with delays for better UX
      const algorithm = new KasiskiAlgorithm(ciphertext);
      
      // Step 1: Input validation
      await new Promise(resolve => setTimeout(resolve, 500));
      setCurrentStep(2);
      updateStepStatus(2, false, true);
      
      // Step 2: Find patterns
      await new Promise(resolve => setTimeout(resolve, 1000));
      setCurrentStep(3);
      updateStepStatus(3, false, true);
      
      // Step 3: Calculate distances
      await new Promise(resolve => setTimeout(resolve, 1000));
      setCurrentStep(4);
      updateStepStatus(4, false, true);
      
      // Step 4: Factor analysis
      await new Promise(resolve => setTimeout(resolve, 1000));
      setCurrentStep(5);
      updateStepStatus(5, false, true);
      
      // Step 5: Frequency analysis
      await new Promise(resolve => setTimeout(resolve, 1500));
      setCurrentStep(6);
      updateStepStatus(6, false, true);
      
      // Step 6: Key reconstruction
      await new Promise(resolve => setTimeout(resolve, 1000));
      setCurrentStep(7);
      updateStepStatus(7, false, true);
      
      // Step 7: Final decryption and generate all solutions
      await new Promise(resolve => setTimeout(resolve, 1000));
      const result = algorithm.performCompleteAnalysis();
      setAnalysisResult({
        ...result,
        currentStep: 7
      });
      
      updateStepStatus(7, true, false);
      
    } catch (error) {
      console.error("Analysis failed:", error);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleReset = () => {
    setCiphertext("");
    setSteps(INITIAL_STEPS);
    setCurrentStep(1);
    setAnalysisResult(null);
    setIsAnalyzing(false);
  };

  const handleExampleSelect = (example: string) => {
    const exampleData = EXAMPLE_CIPHERTEXTS.find(ex => ex.name === example);
    if (exampleData) {
      setCiphertext(exampleData.value);
    }
  };

  const renderCurrentStepContent = () => {
    if (!analysisResult && currentStep === 1) {
      return (
        <CiphertextInput 
          ciphertext={ciphertext}
          onCiphertextChange={setCiphertext}
          onExampleSelect={handleExampleSelect}
          examples={EXAMPLE_CIPHERTEXTS}
          data-testid="ciphertext-input-section"
        />
      );
    }

    if (!analysisResult) return null;

    switch (currentStep) {
      case 2:
        return <PatternDetection patterns={analysisResult.patterns} ciphertext={analysisResult.ciphertext} data-testid="pattern-detection-section" />;
      case 3:
        return <DistanceAnalysis patterns={analysisResult.patterns} distances={analysisResult.distances} data-testid="distance-analysis-section" />;
      case 4:
        return <KeyLengthAnalysis keyLengthCandidates={analysisResult.keyLengthCandidates} data-testid="key-length-analysis-section" />;
      case 5:
        return <FrequencyAnalysis analyses={analysisResult.selectedSolution.frequencyAnalysis} keyLength={analysisResult.selectedSolution.keyLength} data-testid="frequency-analysis-section" />;
      case 6:
        return <KeyReconstruction frequencyAnalysis={analysisResult.selectedSolution.frequencyAnalysis} reconstructedKey={analysisResult.selectedSolution.reconstructedKey} data-testid="key-reconstruction-section" />;
      case 7:
        return <FinalDecryption ciphertext={analysisResult.ciphertext} keySolutions={analysisResult.keySolutions} selectedSolution={analysisResult.selectedSolution} data-testid="final-decryption-section" />;
      default:
        return (
          <CiphertextInput 
            ciphertext={ciphertext}
            onCiphertextChange={setCiphertext}
            onExampleSelect={handleExampleSelect}
            examples={EXAMPLE_CIPHERTEXTS}
            data-testid="ciphertext-input-section"
          />
        );
    }
  };

  return (
    <div className="min-h-screen flex bg-background dark:bg-background">
      <Sidebar 
        steps={steps} 
        currentStep={currentStep}
        progress={(steps.filter(s => s.completed).length / steps.length) * 100}
        data-testid="sidebar"
      />
      
      <div className="flex-1 p-6 overflow-y-auto">
        {/* Header Actions */}
        <div className="flex justify-between items-center mb-6">
          <div className="flex items-center gap-4">
            <Button 
              onClick={handleStartAnalysis}
              disabled={!ciphertext.trim() || isAnalyzing}
              className="bg-primary text-primary-foreground hover:bg-primary/90 dark:bg-primary dark:text-primary-foreground dark:hover:bg-primary/90"
              data-testid="button-start-analysis"
            >
              <Play className="mr-2 h-4 w-4" />
              {isAnalyzing ? "Analyzing..." : "Start Analysis"}
            </Button>
            <Button 
              variant="secondary"
              onClick={handleReset}
              disabled={isAnalyzing}
              className="bg-secondary text-secondary-foreground hover:bg-secondary/80 dark:bg-secondary dark:text-secondary-foreground dark:hover:bg-secondary/80"
              data-testid="button-reset"
            >
              <RotateCcw className="mr-2 h-4 w-4" />
              Reset
            </Button>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" data-testid="button-settings">
              <Settings className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="sm" data-testid="button-help">
              <HelpCircle className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* Main Content */}
        <AnimatePresence mode="wait">
          <motion.div
            key={currentStep}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3 }}
            className="fade-in"
          >
            {renderCurrentStepContent()}
          </motion.div>
        </AnimatePresence>

        {/* Navigation Controls */}
        {analysisResult && (
          <div className="flex justify-between items-center mt-8">
            <Button 
              variant="secondary"
              onClick={() => setCurrentStep(Math.max(1, currentStep - 1))}
              disabled={currentStep === 1}
              className="bg-secondary text-secondary-foreground hover:bg-secondary/80 dark:bg-secondary dark:text-secondary-foreground dark:hover:bg-secondary/80"
              data-testid="button-previous-step"
            >
              Previous Step
            </Button>
            
            <div className="flex items-center gap-4">
              <span className="text-sm text-muted-foreground dark:text-muted-foreground">
                Step {currentStep} of {steps.length}
              </span>
              <Button 
                onClick={() => setCurrentStep(Math.min(7, currentStep + 1))}
                disabled={currentStep === 7}
                className="bg-accent text-accent-foreground hover:bg-accent/90 dark:bg-accent dark:text-accent-foreground dark:hover:bg-accent/90"
                data-testid="button-next-step"
              >
                Next Step
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
