import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Check, Lightbulb } from "lucide-react";
import { KasiskiStep } from "@/types/kasiski";

interface SidebarProps {
  steps: KasiskiStep[];
  currentStep: number;
  progress: number;
}

const STEP_DESCRIPTIONS: { [key: number]: string } = {
  1: "Enter or select a Vigenère ciphertext to begin the cryptanalysis process.",
  2: "Identify repeated patterns in the ciphertext that may reveal key information.",
  3: "Calculate distances between repeated patterns to find potential key lengths.",
  4: "Analyze common factors of distances to determine the most likely key length.",
  5: "Perform frequency analysis on each cipher alphabet to identify letter patterns.",
  6: "Reconstruct the encryption key using frequency analysis results.",
  7: "Decrypt the ciphertext using the reconstructed key to reveal the plaintext."
};

export function Sidebar({ steps, currentStep, progress }: SidebarProps) {
  return (
    <div className="w-80 bg-card dark:bg-card border-r border-border dark:border-border p-6 overflow-y-auto">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-primary dark:text-primary mb-2" data-testid="sidebar-title">
          Kasiski Algorithm
        </h1>
        <p className="text-muted-foreground dark:text-muted-foreground text-sm">
          Cryptanalysis of Vigenère Cipher
          
        </p>
        <p className="font-medium text-accent dark:text-accent mb-2 flex items-center gap-2 text-sm"><a href="https://cve-1803-96.github.io/">| CVE-180396.</a></p>
      </div>
      
      {/* Progress Indicator */}
      <div className="mb-6">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm font-medium">Progress</span>
          <span className="text-sm text-muted-foreground dark:text-muted-foreground" data-testid="progress-text">
            {Math.floor(progress / 100 * steps.length)}/{steps.length}
          </span>
        </div>
        <Progress value={progress} className="w-full" data-testid="progress-bar" />
      </div>
      
      {/* Algorithm Steps */}
      <div className="space-y-2 mb-8">
        {steps.map((step) => (
          <div
            key={step.id}
            className={`p-3 rounded-lg border transition-all duration-200 ${
              step.active
                ? "bg-accent/10 border-2 border-accent dark:bg-accent/10 dark:border-accent step-active"
                : step.completed
                ? "bg-muted/50 border-border dark:bg-muted/50 dark:border-border"
                : "bg-secondary/50 border-border opacity-60 dark:bg-secondary/50 dark:border-border"
            }`}
            data-testid={`step-${step.id}`}
          >
            <div className="flex items-center gap-3">
              <div
                className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-medium ${
                  step.completed
                    ? "bg-accent text-accent-foreground dark:bg-accent dark:text-accent-foreground"
                    : step.active
                    ? "bg-accent text-accent-foreground dark:bg-accent dark:text-accent-foreground"
                    : "bg-muted text-muted-foreground dark:bg-muted dark:text-muted-foreground"
                }`}
              >
                {step.completed ? <Check className="h-3 w-3" /> : step.id}
              </div>
              <span className="text-sm font-medium">{step.name}</span>
            </div>
          </div>
        ))}
      </div>
      
      {/* Help Section */}
      <Card className="bg-accent/5 border-accent/20 dark:bg-accent/5 dark:border-accent/20">
        <CardContent className="p-4">
          <h3 className="font-medium text-accent dark:text-accent mb-2 flex items-center gap-2">
            <Lightbulb className="h-4 w-4" />
            Current Step
          </h3>
          <p className="text-sm text-muted-foreground dark:text-muted-foreground" data-testid="step-description">
            {STEP_DESCRIPTIONS[currentStep] || "Select a step to see its description."}
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
