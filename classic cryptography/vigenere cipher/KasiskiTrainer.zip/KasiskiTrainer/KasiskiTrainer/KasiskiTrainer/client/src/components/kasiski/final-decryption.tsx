import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Copy, Download, CheckCircle, Unlock, Key } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

import { KeySolution } from "@/types/kasiski";

interface FinalDecryptionProps {
  ciphertext: string;
  keySolutions: KeySolution[];
  selectedSolution: KeySolution;
}

export function FinalDecryption({ ciphertext, keySolutions, selectedSolution }: FinalDecryptionProps) {
  const { toast } = useToast();
  const [showComparison, setShowComparison] = useState(false);
  const [currentSolution, setCurrentSolution] = useState(selectedSolution);

  const handleCopyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text).then(() => {
      toast({
        title: "Copied!",
        description: `${label} copied to clipboard`,
      });
    });
  };

  const handleDownload = () => {
    const content = `KASISKI ALGORITHM ANALYSIS RESULTS
=====================================

Original Ciphertext:
${ciphertext}

Selected Solution: ${currentSolution.label}
Key Length: ${currentSolution.keyLength}
Reconstructed Key: ${currentSolution.reconstructedKey}
Confidence: ${Math.round(currentSolution.confidence)}%

Decrypted Plaintext:
${currentSolution.plaintext}

All Solutions:
${keySolutions.map(sol => `- ${sol.label}: Key "${sol.reconstructedKey}" (${Math.round(sol.confidence)}%)`).join('\n')}

Analysis completed on: ${new Date().toLocaleString()}
`;
    
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'kasiski_analysis_results.txt';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    toast({
      title: "Downloaded!",
      description: "Analysis results saved to file",
    });
  };

  const formatTextWithSpacing = (text: string, spacing: number = 5) => {
    return text.replace(new RegExp(`(.{${spacing}})`, 'g'), '$1 ').trim();
  };

  const handleSolutionChange = (solutionLabel: string) => {
    const solution = keySolutions.find(s => s.label === solutionLabel);
    if (solution) {
      setCurrentSolution(solution);
    }
  };

  return (
    <div className="space-y-6">
      {/* Success Header */}
      <Card className="bg-gradient-to-br from-chart-3/5 to-chart-3/10 dark:from-chart-3/5 dark:to-chart-3/10 border-2 border-chart-3/20 dark:border-chart-3/20">
        <CardHeader>
          <div className="flex items-center gap-3">
            <div className="p-2 bg-chart-3/20 dark:bg-chart-3/20 rounded-lg">
              <Unlock className="h-6 w-6 text-chart-3 dark:text-chart-3" />
            </div>
            <div>
              <CardTitle className="text-xl font-semibold text-chart-3 dark:text-chart-3">
                Decryption Complete!
              </CardTitle>
              <p className="text-sm text-muted-foreground dark:text-muted-foreground">
                The Vigenère cipher has been successfully broken - select your preferred solution below
              </p>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Key Solution Selection */}
      <Card className="bg-card dark:bg-card border border-border dark:border-border">
        <CardHeader>
          <CardTitle className="text-lg font-semibold flex items-center gap-2">
            <Key className="h-5 w-5" />
            Select Key Solution
          </CardTitle>
          <p className="text-sm text-muted-foreground dark:text-muted-foreground">
            Choose between different key length candidates and their reconstructed solutions
          </p>
        </CardHeader>
        <CardContent>
          <Tabs value={currentSolution.label} onValueChange={handleSolutionChange}>
            <TabsList className="grid w-full grid-cols-3">
              {keySolutions.map((solution) => (
                <TabsTrigger 
                  key={solution.label} 
                  value={solution.label}
                  className="data-[state=active]:bg-accent data-[state=active]:text-accent-foreground"
                  data-testid={`tab-${solution.label.toLowerCase()}`}
                >
                  {solution.label}
                </TabsTrigger>
              ))}
            </TabsList>
            
            {keySolutions.map((solution) => (
              <TabsContent key={solution.label} value={solution.label} className="mt-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                  <div className="text-center p-4 bg-secondary/30 dark:bg-secondary/30 rounded-lg">
                    <div className="text-2xl font-mono font-bold text-accent dark:text-accent mb-1">
                      {solution.reconstructedKey}
                    </div>
                    <div className="text-sm text-muted-foreground dark:text-muted-foreground">
                      Reconstructed Key
                    </div>
                  </div>
                  <div className="text-center p-4 bg-secondary/30 dark:bg-secondary/30 rounded-lg">
                    <div className="text-2xl font-bold text-accent dark:text-accent mb-1">
                      {solution.keyLength}
                    </div>
                    <div className="text-sm text-muted-foreground dark:text-muted-foreground">
                      Key Length
                    </div>
                  </div>
                  <div className="text-center p-4 bg-secondary/30 dark:bg-secondary/30 rounded-lg">
                    <div className="text-2xl font-bold text-accent dark:text-accent mb-1">
                      {Math.round(solution.confidence)}%
                    </div>
                    <div className="text-sm text-muted-foreground dark:text-muted-foreground">
                      Confidence
                    </div>
                  </div>
                </div>
              </TabsContent>
            ))}
          </Tabs>
        </CardContent>
      </Card>

      {/* Current Solution Summary */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="bg-card dark:bg-card border border-border dark:border-border">
          <CardHeader>
            <CardTitle className="text-lg font-semibold flex items-center gap-2">
              <CheckCircle className="h-5 w-5 text-chart-3 dark:text-chart-3" />
              Current Solution: {currentSolution.label}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-center mb-4">
              <div 
                className="text-3xl font-mono font-bold text-accent dark:text-accent mb-2 tracking-wider"
                data-testid="final-key"
              >
                {currentSolution.reconstructedKey}
              </div>
              <Badge variant="default" className="bg-accent text-accent-foreground dark:bg-accent dark:text-accent-foreground">
                {currentSolution.keyLength} characters
              </Badge>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => handleCopyToClipboard(currentSolution.reconstructedKey, "Key")}
              className="w-full"
              data-testid="button-copy-key"
            >
              <Copy className="mr-2 h-4 w-4" />
              Copy Key
            </Button>
          </CardContent>
        </Card>

        <Card className="bg-card dark:bg-card border border-border dark:border-border">
          <CardHeader>
            <CardTitle className="text-lg font-semibold">Analysis Summary</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground dark:text-muted-foreground">Original Length:</span>
                <span className="font-mono" data-testid="original-length">{ciphertext.length}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground dark:text-muted-foreground">Key Length:</span>
                <span className="font-mono" data-testid="key-length">{currentSolution.keyLength}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground dark:text-muted-foreground">Plaintext Length:</span>
                <span className="font-mono" data-testid="plaintext-length">{currentSolution.plaintext.length}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground dark:text-muted-foreground">Confidence:</span>
                <span className="font-medium">{Math.round(currentSolution.confidence)}%</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Decrypted Text */}
      <Card className="bg-card dark:bg-card border border-border dark:border-border">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg font-semibold">Decrypted Plaintext</CardTitle>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowComparison(!showComparison)}
                data-testid="button-toggle-comparison"
              >
                {showComparison ? "Hide" : "Show"} Comparison
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleCopyToClipboard(currentSolution.plaintext, "Plaintext")}
                data-testid="button-copy-plaintext"
              >
                <Copy className="mr-2 h-4 w-4" />
                Copy
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Textarea
            value={formatTextWithSpacing(currentSolution.plaintext)}
            readOnly
            className="w-full h-32 p-4 bg-chart-3/5 dark:bg-chart-3/5 border border-chart-3/20 dark:border-chart-3/20 rounded-lg font-mono text-sm resize-none"
            data-testid="textarea-plaintext"
          />
          <div className="flex items-center justify-between mt-2">
            <span className="text-sm text-muted-foreground dark:text-muted-foreground">
              Formatted with spacing for readability
            </span>
            <Badge variant="secondary" className="bg-chart-3/10 text-chart-3 dark:bg-chart-3/10 dark:text-chart-3">
              {currentSolution.label} Solution
            </Badge>
          </div>
        </CardContent>
      </Card>

      {/* Comparison View */}
      {showComparison && (
        <Card className="bg-card dark:bg-card border border-border dark:border-border">
          <CardHeader>
            <CardTitle className="text-lg font-semibold">Cipher vs Plaintext Comparison</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <div className="text-sm font-medium mb-2 text-muted-foreground dark:text-muted-foreground">
                  Original Ciphertext:
                </div>
                <div 
                  className="p-3 bg-secondary/30 dark:bg-secondary/30 rounded font-mono text-sm break-all"
                  data-testid="comparison-ciphertext"
                >
                  {formatTextWithSpacing(ciphertext)}
                </div>
              </div>
              <div>
                <div className="text-sm font-medium mb-2 text-muted-foreground dark:text-muted-foreground">
                  Decrypted Plaintext:
                </div>
                <div 
                  className="p-3 bg-chart-3/10 dark:bg-chart-3/10 rounded font-mono text-sm break-all"
                  data-testid="comparison-plaintext"
                >
                  {formatTextWithSpacing(currentSolution.plaintext)}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Action Buttons */}
      <div className="flex justify-center gap-4">
        <Button
          onClick={handleDownload}
          className="bg-primary text-primary-foreground hover:bg-primary/90 dark:bg-primary dark:text-primary-foreground dark:hover:bg-primary/90"
          data-testid="button-download-results"
        >
          <Download className="mr-2 h-4 w-4" />
          Download Results
        </Button>
        <Button
          variant="outline"
          onClick={() => window.location.reload()}
          data-testid="button-new-analysis"
        >
          Start New Analysis
        </Button>
      </div>
    </div>
  );
}
