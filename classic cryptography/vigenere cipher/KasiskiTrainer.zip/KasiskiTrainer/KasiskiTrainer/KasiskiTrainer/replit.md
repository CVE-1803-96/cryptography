# Overview

This is a web-based Kasiski Algorithm analyzer for breaking Vigenère ciphers. The application provides an interactive, step-by-step cryptanalysis tool that demonstrates how the Kasiski examination method works to determine the key length and ultimately decrypt polyalphabetic substitution ciphers. The application guides users through pattern detection, distance analysis, factor analysis, frequency analysis, key reconstruction, and final decryption with visual feedback and educational explanations.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
The frontend is built with React and TypeScript using Vite as the build tool. The application follows a component-based architecture with:

- **UI Framework**: React with shadcn/ui component library for consistent design
- **Styling**: Tailwind CSS with CSS variables for theming support
- **State Management**: React hooks and context for local state, TanStack Query for server state
- **Routing**: Wouter for lightweight client-side routing
- **Animations**: Framer Motion for smooth transitions and visual feedback
- **Charts**: Recharts for data visualization in frequency and distance analysis

The application uses a single-page application (SPA) pattern with component-based organization under `client/src/components/kasiski/` for algorithm-specific components.

## Backend Architecture
The backend follows a REST API pattern built with Express.js:

- **Server Framework**: Express.js with TypeScript support
- **API Design**: RESTful endpoints under `/api/kasiski/` namespace
- **Storage Layer**: Abstracted storage interface with in-memory implementation (MemStorage)
- **Data Validation**: Zod schemas for request/response validation
- **Development Setup**: Hot reloading with Vite middleware integration

The storage layer is designed to be pluggable, currently using in-memory storage but structured to easily swap in database implementations.

## Data Storage Solutions
Currently uses in-memory storage with structured interfaces:

- **Storage Interface**: `IStorage` defines contracts for user and analysis operations
- **Data Models**: Drizzle ORM schemas define PostgreSQL table structures for future database integration
- **Schema Validation**: Drizzle-zod integration for type-safe data validation

The application is configured for PostgreSQL through Drizzle ORM but currently operates with in-memory storage for simplicity.

## Authentication and Authorization
The application currently has user schema definitions but no active authentication implementation. The storage layer includes user management interfaces prepared for future authentication integration.

# External Dependencies

## Database
- **Neon Database**: Serverless PostgreSQL configured through `@neondatabase/serverless`
- **ORM**: Drizzle ORM with PostgreSQL dialect for database operations
- **Schema Management**: Drizzle Kit for migrations and schema management

## UI and Styling
- **Component Library**: Radix UI primitives for accessible, unstyled components
- **Styling**: Tailwind CSS with shadcn/ui design system
- **Icons**: Lucide React for consistent iconography
- **Fonts**: Google Fonts (Inter, JetBrains Mono) for typography

## State Management and Data Fetching
- **Query Management**: TanStack React Query for server state synchronization
- **Form Handling**: React Hook Form with Hookform Resolvers for form validation
- **Validation**: Zod for runtime type checking and schema validation

## Development and Build Tools
- **Build Tool**: Vite with React plugin and TypeScript support
- **Development**: Replit-specific plugins for runtime error handling and development banner
- **Code Quality**: TypeScript with strict configuration for type safety

## Visualization and Animation
- **Charts**: Recharts for rendering frequency analysis and distance distribution charts
- **Animations**: Framer Motion for smooth step transitions and visual feedback
- **Data Visualization**: Custom highlighting system for pattern detection in ciphertext

## Utilities
- **Date Handling**: date-fns for date manipulation and formatting
- **Styling Utilities**: clsx and class-variance-authority for conditional styling
- **CSS Processing**: PostCSS with Tailwind CSS and Autoprefixer